import Home from "./Home";
import './Style.css';

function App() {
  return (
    <div className="body">
      <Home/>
    </div>
  );
}

export default App;
