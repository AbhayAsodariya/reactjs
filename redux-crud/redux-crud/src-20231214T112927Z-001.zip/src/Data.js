export const userList = [
    {
        "name":"Priyanshi",
        "email":"p@gmail.com",
        "id":1
    },
    {
        "name":"Riddhi",
        "email":"r@gmail.com",
        "id":2
    }
]

// userlist[userlist.length-1].id + 1