
import './style.css';
import Vehicallist from './Vehical-list';
import "../node_modules/bootstrap/dist/css/bootstrap.css"

function App() {
  return (
    
    <div>
    
    <Vehicallist/>
    </div>
  );
}

export default App;
